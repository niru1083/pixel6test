import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoneFormDataComponent } from './lone-form-data/lone-form-data.component';

const routes: Routes = [
  {path:"",component:LoneFormDataComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
