import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoneFormDataComponent } from './lone-form-data.component';

describe('LoneFormDataComponent', () => {
  let component: LoneFormDataComponent;
  let fixture: ComponentFixture<LoneFormDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoneFormDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoneFormDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
