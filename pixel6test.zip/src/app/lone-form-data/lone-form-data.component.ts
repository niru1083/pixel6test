import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-lone-form-data',
  templateUrl: './lone-form-data.component.html',
  styleUrls: ['./lone-form-data.component.css']
})
export class LoneFormDataComponent implements OnInit {
  title = 'pixel6';

  // for store data
  data:any;
  data1:any;
  mydata: any;

  fullname:any;
  inputvalue:any;

  // for hide and show 
  enablebutton = false;
  showresendbutton = false;
  registrationdone = true;
  Success1 = false;
  showalt =false;
  
  timespent = 0;
  count=1;


  constructor(private http:HttpClient) {}

  ngOnInit(): void {
   this.mydata = new FormGroup(
     {
       city : new FormControl("",Validators.required),
       panNumber : new FormControl("",Validators.compose([Validators.required, Validators.pattern(/[A-Z]{5}[0-9]{4}[A-Z]{1}$/)])),
       fullname : new FormControl("",Validators.compose([Validators.required,Validators.maxLength(140)])),
       email: new FormControl("", Validators.compose([Validators.required, Validators.pattern(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)])),
       mobile: new FormControl("", Validators.compose([Validators.required, Validators.pattern(/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/)])),
       otp: new FormControl("", Validators.compose([Validators.required, Validators.min(1000), Validators.max(9999)]))
     }
   )
  }

 
  sendOTP(mydata : any)
  {
    
    if(mydata.controls.mobile.invalid == false)
    {
      this.timespent = 0;
      let data={
        "city": mydata.controls.city.value,
        "panNumber": mydata.controls.panNumber.value,
        "fullname" : mydata.controls.fullname.value,
        "email" :  mydata.controls.email.value,
        "mobile" : mydata.controls.mobile.value,
      }
      console.log(data);
      // for post data and get res
      this.http.post("http://apps.thinkoverit.com/api/getOTP.php", data).subscribe((data: any) => {
      
       console.log(data);
      // fliter data
      if (data.status == "Success") {
      
          let interval = setInterval(() => {
            this.timespent++; 
            if (this.count==3){  // for resend otp 3 click off btn
              this.showresendbutton=false;
              this.showalt=true;
            }
            else{

            
            if (this.timespent < 180) {  //time resend otp
              this.enablebutton = false;
              this.showresendbutton = false;
            } 
            else {
              this.enablebutton = true;
              this.showresendbutton = true;
              clearInterval(interval);
            }
          }
            
            
          }, 1000);
        }
        else{
          alert("Something went wrong.");
        }
      });


      
    }
  }

  verifyOTP(mydata: any) {
    if (mydata.invalid == false) {

      //get data mobile and otp just
      let data1 = {
        "mobile" : mydata.controls.mobile.value,
        "otp" : mydata.controls.mobile.value,
      }



      this.http.post("http://apps.thinkoverit.com/api/verifyOTP.php", data1).subscribe(
        (data: any) => {
          console.log(data);


          if (data.status == "Success"){  //compare res data
          this.registrationdone = false;
          this.Success1= true;
          this.fullname = mydata.controls.fullname.value; //for display full name
          }
          else{
            // alert("un varifide Otp")
            window.alert(console.error(data)
            )
          }
        }
      );
    }
    else{
      alert("err")
    }
  }
}
